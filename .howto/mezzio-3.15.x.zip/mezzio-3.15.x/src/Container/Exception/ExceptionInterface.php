<?php

declare(strict_types=1);

namespace Mezzio\Container\Exception;

/**
 * Marker interface for container exceptions.
 */
interface ExceptionInterface
{
}
