<?php

declare(strict_types=1);

namespace Mezzio\Exception;

class RuntimeException extends \RuntimeException implements
    ExceptionInterface
{
}
