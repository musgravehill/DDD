<?php

declare(strict_types=1);

namespace Mezzio\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements
    ExceptionInterface
{
}
